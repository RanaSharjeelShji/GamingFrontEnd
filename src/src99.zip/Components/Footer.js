import React from "react";
import { Link } from "react-router-dom";
const Footer = () => {
  return (
    <div>
   <footer class="footer-part">
      <div class="px-5">
        <div class="row newsletter">
          <div class="col-lg-6">
            <div class="news-content">
              <h2>Subscribe for Latest Offers</h2>
              <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                Laboriosam, aliquid reiciendis! Exercitationem soluta provident
                non.
              </p>
            </div>
          </div>
          <div class="col-lg-6">
            <form class="news-form">
              <input type="text" placeholder="Enter Your Email Address"/><button class="btn btn-inline">
                <i class="fas fa-envelope"></i><span>Subscribe</span>
              </button>
            </form>
          </div>
        </div>
        <div class="row pb-5">
          <div class="col-sm-6 col-md-6 col-lg-3">
            <div class="footer-content">
              <h3>Contact Us</h3>
              <ul class="footer-address">
                <li>
                  <i class="fas fa-map-marker-alt"></i>
                  <p>
                    1420 West Jalkuri Fatullah, <span>Narayanganj, BD</span>
                  </p>
                </li>
                <li>
                  <i class="fas fa-envelope"></i>
                  <p>support@classicads.com <span>info@classicads.com</span></p>
                </li>
                <li>
                  <i class="fas fa-phone-alt"></i>
                  <p>+8801838288389 <span>+8801941101915</span></p>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-3">
            <div class="footer-content">
              <h3>Quick Links</h3>
              <ul class="footer-widget">
                <li><a href="a">Store Location</a></li>
                <li><a href="a">Orders Tracking</a></li>
                <li><a href="a">My Account</a></li>
                <li><a href="a">Size Guide</a></li>
                <li><a href="a">Faq</a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-3">
            <div class="footer-content">
              <h3>Information</h3>
              <ul class="footer-widget">
                <li><a href="a">About Us</a></li>
                <li><a href="a">Delivery System</a></li>
                <li><a href="a">Secure Payment</a></li>
                <li><a href="a">Contact Us</a></li>
                <li><a href="a">Sitemap</a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-3">
            <div class="footer-info">
            <div className="d-flex align-items-center">
              <img width={35} src="/images/pexels/game.png" alt=""/>
            <Link>
              {/* <img src="images/logo.png" alt="logo" /> */}
              <p className="px-2 pt-4" style={{fontWeight:'bold',fontSize:'1.8rem',color:'#0044BB'}}>
              GameTradeHub<span style={{color:'#6F6FFF'}}></span>
              </p>
            </Link>
            </div>
              <ul class="footer-count">
                <li>
                  <h5>929,238</h5>
                  <p>Registered Users</p>
                </li>
                <li>
                  <h5>242,789</h5>
                  <p>Community Ads</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
    </div>
  );
};

export default Footer;
