import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
// import { useNavigate } from "react-router-dom";
const Form = () => {
  const [registerData, setRegisterData] = useState({
    name: "",
    phone: "",
    password: "",
    place: "",
    email: "",

  });
  const [signInData, setSignInData] = useState({
    email: "",
    password: "",
  });

  const handleLogin = (event) => {
    const { name, value } = event.target;
    setSignInData({
      ...signInData,
      [name]: value,
    });
  };
  const handleSignIn = (e) => {
    e.preventDefault();

    axios
      .post("http://localhost:8000/api/login", signInData)
      .then((response) => {
        if (response.status === 200) {
          toast.success("Sign-in successful!");
          setSignInData({
            email: "",
            password: "",
          });
        } else {
          console.error("Sign-in failed:", response.data);
          toast.error("Sign-in failed. Please check your credentials.");
        }
      })
      .catch((error) => {
        console.error("Sign-in error:", error);
        toast.error("Sign-in failed. Please check your credentials.");
      });
  };
  

  const handleOnChange = (event) => {
    const { name, value } = event.target;

    setRegisterData({
      ...registerData,
      [name]: value,
    });
  };

  const handleRegister = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:8000/api/register", registerData)
      .then((response) => {
        if (response.status === 200) {
          const token = response.data?.data?.token;
          if (token) {
            localStorage.setItem("token", token);
          }
          toast.success("Registration successful!");
          setRegisterData({
            phone: "",
            password: "",
            name: "",
            place: "",
            email: "",
          });
        } else {
          console.error("Registration failed:", response.data); 
          toast.error("Registration failed. Please try again.");
        }
      })
      .catch((error) => {
        console.error("Registration error:", error);
        toast.error("Registration failed. Please try again.");
      });
  };
  return (
    <div>
      <section className="user-form-part">
        <div className="user-form-banner">
          <div className="user-form-content">
            <div className="d-flex align-items-center justify-content-center">
              <img width={60} src="/images/pexels/game.png" alt=""/>
            <Link>
              {/* <img src="images/logo.png" alt="logo" /> */}
              <p className="pt-4 mt-2 px-2" style={{fontWeight:'bold',fontSize:'3rem',color:'#4444FF'}}>
              GameTradeHub<span style={{color:'#6F6FFF'}}></span>
              </p>
            </Link>
            </div>
            {/* <h1>
            Welcome to GameTradeHub!
            </h1> */}
            <span className="text-white text-center" style={{fontSize:'1.1rem'}}> The ultimate hub for gamers to buy, sell, and trade their way <br/> to gaming greatness!
           </span>
          </div>
        </div>
        <div className="user-form-category">
          <div className="user-form-header">
            <Link>
              <img src="images/logo.png" alt="logo" />
            </Link>
            <a href="index.html">
              <i className="fas fa-arrow-left"></i>
            </a>
          </div>
          <div className="user-form-category-btn">
            <ul className="nav nav-tabs">
              <li>
                <a href="#login-tab" className="nav-link active" data-toggle="tab">
                  sign in
                </a>
              </li>
              <li>
                <a href="#register-tab" className="nav-link" data-toggle="tab">
                  sign up
                </a>
              </li>
            </ul>
          </div>
          <div className="tab-pane active" id="login-tab">
            <div className="user-form-title">
              <h2>Welcome!</h2>
              <p>Use credentials to access your account.</p>
            </div>
            <form onSubmit={handleSignIn}>
              <div className="row">
                <div className="col-12">
                  <div className="form-group">
                    <input
                      type="email"
                      name="email"
                      className="form-control"
                      placeholder="Email"
                      value={signInData.email}
                      onChange={handleLogin}
                    />
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group">
                    <input
                      type="password"
                      className="form-control"
                      id="pass"
                      name="password"
                      placeholder="Password"
                      value={signInData.password}
                      onChange={handleLogin}
                    />
                    <button type="button" className="form-icon">
                      <i className="eye fas fa-eye"></i>
                    </button>
                    <small className="form-alert">
                      Password must be 6 characters
                    </small>
                  </div>
                </div>
                <div className="col-6">
                  <div className="form-group text-right">
                    <Link className="form-forgot">
                      Forgot password?
                    </Link>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group">
                    <button type="submit" className="btn btn-inline">
                      <i className="fas fa-unlock"></i>
                      <span>Enter your account</span>
                    </button>
                  </div>
                </div>
              </div>
            </form>
            <div className="user-form-direction">
              <p>
                Don't have an account? click on the <span>( sign up )</span>
                button above.
              </p>
            </div>
          </div>
          {/* sign up */}
          <div className="tab-pane" id="register-tab">
            <div className="user-form-title">
              <h2>Register</h2>
              <p>Setup a new account in a minute.</p>
            </div>
            <form onSubmit={handleRegister}>
              <div className="row">
              <div className="col-12">
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Name"
                      name="name"
                      value={registerData.name}
                      onChange={handleOnChange}
                    />
                    <small className="form-alert">
                      Please follow this example - 01XXXXXXXXX
                    </small>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="place"
                      name="place"
                      value={registerData.place}
                      onChange={handleOnChange}
                    />
                    <small className="form-alert">
                      Please follow this example - 01XXXXXXXXX
                    </small>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Email"
                      name="email"
                      value={registerData.email}
                      onChange={handleOnChange}
                    />
                    <small className="form-alert">
                      Please follow this example - 01XXXXXXXXX
                    </small>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Phone number"
                      name="phone"
                      value={registerData.phone}
                      onChange={handleOnChange}
                    />
                    <small className="form-alert">
                      Please follow this example - 01XXXXXXXXX
                    </small>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group">
                    <input
                      type="password"
                      className="form-control"
                      placeholder="Password"
                      name="password"
                      value={registerData.password}
                      onChange={handleOnChange}
                    />
                    <button className="form-icon">
                      <i className="eye fas fa-eye"></i>
                    </button>
                    <small className="form-alert">
                      Password must be 6 characters
                    </small>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group">
                    <button type="submit" className="btn btn-inline">
                      <i className="fas fa-user-check"></i>
                      <span>Create new account</span>
                    </button>
                  </div>
                </div>
              </div>
            </form>
            <div className="user-form-direction">
              <p>
                Already have an account? click on the
                <span>( sign in )</span>button above.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Form;
