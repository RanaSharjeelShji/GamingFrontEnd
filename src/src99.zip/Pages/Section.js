import React from "react";
import { useState } from "react";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import { Link } from "react-router-dom";
import Modal from "./Modal/Modal";
const Section = () => {
  const [openModal, setOpenModal] = useState(false);
  return (
    <div>
      <Header />
      {openModal ? (
        <div className="position-absolute">
          <Modal />
        </div>
      ) : (
        ""
      )}
      <section class="banner-part">
        <div class="mx-5">
          <div class="banner-content">
            <h1>#Buy and #Sell to Level Up Your Gaming Arsenal!</h1>
            <p>
              Explore and Buy or Sell Everything Gaming and Tech in One Dynamic
              Hub!
            </p>
            {/* <Link to="/list" class="btn btn-outline">
              <i class="fas fa-eye"></i>
              <span>Show all ads</span>
            </Link> */}
          </div>
        </div>
      </section>
      <section class="suggest-part">
        <div class="mx-5">
          <div class="suggest-slider slider-arrow d-flex justify-content-between flex-wrap">
            <Link to="/list" class="suggest-card p-5">
              <img
                src="/images/pexels/headset.png"
                alt="car"
                style={{ borderRadius: "10px" }}
              />
              <h6>Headsets</h6>
              <p>(21) supply</p>
            </Link>
            <Link to="/list" class="suggest-card p-5">
              <img
                src="/images/pexels/keyboards.png"
                alt="furniture"
                style={{ borderRadius: "10px" }}
              />
              <h6>Keyboards</h6>
              <p>(10) supply</p>
            </Link>
            <Link to="/list" class="suggest-card p-5">
              <img src="images/pexels/glasses.png" alt="house" />
              <h6>Glasses</h6>
              <p>(234) supply</p>
            </Link>
            <Link to="/list" class="suggest-card p-5">
              <img src="images/pexels/joystick.png" alt="food" />
              <h6>Controllers</h6>
              <p>(8) supply</p>
            </Link>
            <Link to="/list" class="suggest-card p-5">
              <img src="images/pexels/armchair.png" alt="cycle" />
              <h6>Chairs</h6>
              <p>(7) supply</p>
            </Link>
            <Link to="/list" class="suggest-card p-5">
              <img src="images/pexels/web-analytics.png" alt="clothes" />
              <h6>Monitors</h6>
              <p>(17) supply</p>
            </Link>
          </div>
        </div>
      </section>
      <section class="section trend-part">
        <div class="mx-5">
          <div class="row">
            <div class="col-lg-12">
              <div class="section-center-heading">
                <h2>
                  Popular Trending <span>Products</span>
                </h2>
                <p>
                  Discover the Latest in Gaming Excellence with Our Trendsetting
                  Products!
                </p>
              </div>
            </div>
          </div>
          <div class="row justify-content-center">
            <div class="col-md-11 col-lg-8 col-xl-6">
              <div class="product-card standard">
                <div class="product-media">
                  <div class="product-img">
                    <img src="images/product/01.jpg" alt="product" />
                  </div>
                  <div class="cross-vertical-badge product-badge">
                    <i class="fas fa-bolt"></i>
                    <span>trending</span>
                  </div>
                  <div class="product-type">
                    <span class="flat-badge booking">booking</span>
                  </div>
                  <ul class="product-action">
                    <li class="view">
                      <i class="fas fa-eye"></i>
                      <span>264</span>
                    </li>
                    <li class="click">
                      <i class="fas fa-mouse"></i>
                      <span>134</span>
                    </li>
                    <li class="rating">
                      <i class="fas fa-star"></i>
                      <span>4.5/7</span>
                    </li>
                  </ul>
                </div>
                <div class="product-content">
                  <ol class="breadcrumb product-category">
                    <li>
                      <i class="fas fa-tags"></i>
                    </li>
                    <li class="breadcrumb-item">
                      <a href="#">property</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                      house
                    </li>
                  </ol>
                  <h5 class="product-title">
                    <a href="ad-details-right.html">
                      Lorem ipsum dolor sit amet consect adipisicing elit
                    </a>
                  </h5>
                  <div class="product-meta">
                    <span>
                      <i class="fas fa-map-marker-alt"></i>Uttara, Dhaka
                    </span>
                    <span>
                      <i class="fas fa-clock"></i>30 min ago
                    </span>
                  </div>
                  <div class="product-info">
                    <h5 class="product-price">
                      $974<span>/per day</span>
                    </h5>
                    <div class="product-btn">
                      <a
                        href="compare.html"
                        title="Compare"
                        class="fas fa-compress"
                      ></a>
                      <button
                        type="button"
                        title="Wishlist"
                        class="far fa-heart"
                      ></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-11 col-lg-8 col-xl-6">
              <div class="product-card standard">
                <div class="product-media">
                  <div class="product-img">
                    <img src="images/product/02.jpg" alt="product" />
                  </div>
                  <div class="cross-vertical-badge product-badge">
                    <i class="fas fa-bolt"></i>
                    <span>trending</span>
                  </div>
                  <div class="product-type">
                    <span class="flat-badge sale">sale</span>
                  </div>
                  <ul class="product-action">
                    <li class="view">
                      <i class="fas fa-eye"></i>
                      <span>264</span>
                    </li>
                    <li class="click">
                      <i class="fas fa-mouse"></i>
                      <span>134</span>
                    </li>
                    <li class="rating">
                      <i class="fas fa-star"></i>
                      <span>4.5/7</span>
                    </li>
                  </ul>
                </div>
                <div class="product-content">
                  <ol class="breadcrumb product-category">
                    <li>
                      <i class="fas fa-tags"></i>
                    </li>
                    <li class="breadcrumb-item">
                      <a href="#">fashion</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                      shoes
                    </li>
                  </ol>
                  <h5 class="product-title">
                    <a href="ad-details-right.html">
                      Lorem ipsum dolor sit amet consect adipisicing elit
                    </a>
                  </h5>
                  <div class="product-meta">
                    <span>
                      <i class="fas fa-map-marker-alt"></i>Uttara, Dhaka
                    </span>
                    <span>
                      <i class="fas fa-clock"></i>30 min ago
                    </span>
                  </div>
                  <div class="product-info">
                    <h5 class="product-price">
                      $384<span>/fixed</span>
                    </h5>
                    <div class="product-btn">
                      <a
                        href="compare.html"
                        title="Compare"
                        class="fas fa-compress"
                      ></a>
                      <button
                        type="button"
                        title="Wishlist"
                        class="far fa-heart"
                      ></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-11 col-lg-8 col-xl-6">
              <div class="product-card standard">
                <div class="product-media">
                  <div class="product-img">
                    <img src="images/product/03.jpg" alt="product" />
                  </div>
                  <div class="cross-vertical-badge product-badge">
                    <i class="fas fa-bolt"></i>
                    <span>trending</span>
                  </div>
                  <div class="product-type">
                    <span class="flat-badge sale">sale</span>
                  </div>
                  <ul class="product-action">
                    <li class="view">
                      <i class="fas fa-eye"></i>
                      <span>264</span>
                    </li>
                    <li class="click">
                      <i class="fas fa-mouse"></i>
                      <span>134</span>
                    </li>
                    <li class="rating">
                      <i class="fas fa-star"></i>
                      <span>4.5/7</span>
                    </li>
                  </ul>
                </div>
                <div class="product-content">
                  <ol class="breadcrumb product-category">
                    <li>
                      <i class="fas fa-tags"></i>
                    </li>
                    <li class="breadcrumb-item">
                      <a href="#">stationary</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                      book
                    </li>
                  </ol>
                  <h5 class="product-title">
                    <a href="ad-details-right.html">
                      Lorem ipsum dolor sit amet consect adipisicing elit
                    </a>
                  </h5>
                  <div class="product-meta">
                    <span>
                      <i class="fas fa-map-marker-alt"></i>Uttara, Dhaka
                    </span>
                    <span>
                      <i class="fas fa-clock"></i>30 min ago
                    </span>
                  </div>
                  <div class="product-info">
                    <h5 class="product-price">
                      $78<span>/Negotiable</span>
                    </h5>
                    <div class="product-btn">
                      <a
                        href="compare.html"
                        title="Compare"
                        class="fas fa-compress"
                      ></a>
                      <button
                        type="button"
                        title="Wishlist"
                        class="far fa-heart"
                      ></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-11 col-lg-8 col-xl-6">
              <div class="product-card standard">
                <div class="product-media">
                  <div class="product-img">
                    <img src="images/product/04.jpg" alt="product" />
                  </div>
                  <div class="cross-vertical-badge product-badge">
                    <i class="fas fa-bolt"></i>
                    <span>trending</span>
                  </div>
                  <div class="product-type">
                    <span class="flat-badge sale">sale</span>
                  </div>
                  <ul class="product-action">
                    <li class="view">
                      <i class="fas fa-eye"></i>
                      <span>264</span>
                    </li>
                    <li class="click">
                      <i class="fas fa-mouse"></i>
                      <span>134</span>
                    </li>
                    <li class="rating">
                      <i class="fas fa-star"></i>
                      <span>4.5/7</span>
                    </li>
                  </ul>
                </div>
                <div class="product-content">
                  <ol class="breadcrumb product-category">
                    <li>
                      <i class="fas fa-tags"></i>
                    </li>
                    <li class="breadcrumb-item">
                      <a href="#">electronics</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                      television
                    </li>
                  </ol>
                  <h5 class="product-title">
                    <a href="ad-details-right.html">
                      Lorem ipsum dolor sit amet consect adipisicing elit
                    </a>
                  </h5>
                  <div class="product-meta">
                    <span>
                      <i class="fas fa-map-marker-alt"></i>Uttara, Dhaka
                    </span>
                    <span>
                      <i class="fas fa-clock"></i>30 min ago
                    </span>
                  </div>
                  <div class="product-info">
                    <h5 class="product-price">
                      $756<span>/fixed</span>
                    </h5>
                    <div class="product-btn">
                      <a
                        href="compare.html"
                        title="Compare"
                        class="fas fa-compress"
                      ></a>
                      <button
                        type="button"
                        title="Wishlist"
                        class="far fa-heart"
                      ></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-11 col-lg-8 col-xl-6">
              <div class="product-card standard">
                <div class="product-media">
                  <div class="product-img">
                    <img src="images/product/05.jpg" alt="product" />
                  </div>
                  <div class="cross-vertical-badge product-badge">
                    <i class="fas fa-bolt"></i>
                    <span>trending</span>
                  </div>
                  <div class="product-type">
                    <span class="flat-badge sale">sale</span>
                  </div>
                  <ul class="product-action">
                    <li class="view">
                      <i class="fas fa-eye"></i>
                      <span>264</span>
                    </li>
                    <li class="click">
                      <i class="fas fa-mouse"></i>
                      <span>134</span>
                    </li>
                    <li class="rating">
                      <i class="fas fa-star"></i>
                      <span>4.5/7</span>
                    </li>
                  </ul>
                </div>
                <div class="product-content">
                  <ol class="breadcrumb product-category">
                    <li>
                      <i class="fas fa-tags"></i>
                    </li>
                    <li class="breadcrumb-item">
                      <a href="#">gadget</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                      headphone
                    </li>
                  </ol>
                  <h5 class="product-title">
                    <a href="ad-details-right.html">
                      Lorem ipsum dolor sit amet consect adipisicing elit
                    </a>
                  </h5>
                  <div class="product-meta">
                    <span>
                      <i class="fas fa-map-marker-alt"></i>Uttara, Dhaka
                    </span>
                    <span>
                      <i class="fas fa-clock"></i>30 min ago
                    </span>
                  </div>
                  <div class="product-info">
                    <h5 class="product-price">
                      $245<span>/Negotiable</span>
                    </h5>
                    <div class="product-btn">
                      <a
                        href="compare.html"
                        title="Compare"
                        class="fas fa-compress"
                      ></a>
                      <button
                        type="button"
                        title="Wishlist"
                        class="far fa-heart"
                      ></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-11 col-lg-8 col-xl-6">
              <div class="product-card standard">
                <div class="product-media">
                  <div class="product-img">
                    <img src="images/product/06.jpg" alt="product" />
                  </div>
                  <div class="cross-vertical-badge product-badge">
                    <i class="fas fa-bolt"></i>
                    <span>trending</span>
                  </div>
                  <div class="product-type">
                    <span class="flat-badge rent">rent</span>
                  </div>
                  <ul class="product-action">
                    <li class="view">
                      <i class="fas fa-eye"></i>
                      <span>264</span>
                    </li>
                    <li class="click">
                      <i class="fas fa-mouse"></i>
                      <span>134</span>
                    </li>
                    <li class="rating">
                      <i class="fas fa-star"></i>
                      <span>4.5/7</span>
                    </li>
                  </ul>
                </div>
                <div class="product-content">
                  <ol class="breadcrumb product-category">
                    <li>
                      <i class="fas fa-tags"></i>
                    </li>
                    <li class="breadcrumb-item">
                      <a href="#">automobile</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                      cycle
                    </li>
                  </ol>
                  <h5 class="product-title">
                    <a href="ad-details-right.html">
                      Lorem ipsum dolor sit amet consect adipisicing elit
                    </a>
                  </h5>
                  <div class="product-meta">
                    <span>
                      <i class="fas fa-map-marker-alt"></i>Uttara, Dhaka
                    </span>
                    <span>
                      <i class="fas fa-clock"></i>30 min ago
                    </span>
                  </div>
                  <div class="product-info">
                    <h5 class="product-price">
                      $75<span>/per hour</span>
                    </h5>
                    <div class="product-btn">
                      <a
                        href="compare.html"
                        title="Compare"
                        class="fas fa-compress"
                      ></a>
                      <button
                        type="button"
                        title="Wishlist"
                        class="far fa-heart"
                      ></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12">
              <div class="center-20">
                <a href="ad-list-column3.html" class="btn btn-inline">
                  <i class="fas fa-eye"></i>
                  <span>view all trend</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="intro-part">
        <div class="mx-5">
          <div class="row">
            <div class="col-lg-12">
              <div class="section-center-heading">
                <h2>Ready to Sell? Sell Your Gaming Treasures with Us!?</h2>
                <p>
                  Level Up Your Visibility - Unleash Your Gaming Products to the
                  Enthusiastic Community!
                </p>
                <a href="ad-post.html" class="btn btn-outline">
                  <i class="fas fa-plus-circle"></i>
                  <span>post your ad</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="price-part">
        <div class="mx-5">
          <div class="row">
            <div class="col-lg-12">
              <div class="section-center-heading">
                <h2>Best Reliable Pricing Plans</h2>
                <p>
                  Explore Our Best and Most Reliable Plans for Gaming
                  Excellence!
                </p>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 col-lg-4">
              <div class="price-card">
                <div class="price-head">
                  <i class="flaticon-bicycle"></i>
                  <h3>$00</h3>
                  <h4>Free Plan</h4>
                </div>
                <ul class="price-list">
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>1 Regular Ad for 7 days</p>
                  </li>
                  <li>
                    <i class="fas fa-times"></i>
                    <p>No Credit card required</p>
                  </li>
                  <li>
                    <i class="fas fa-times"></i>
                    <p>No Top or Featured Ad</p>
                  </li>
                  <li>
                    <i class="fas fa-times"></i>
                    <p>No Ad will be bumped up</p>
                  </li>
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>Limited Support</p>
                  </li>
                </ul>
                <div class="price-btn">
                  <a href="user-form.html" class="btn btn-inline">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Register Now</span>
                  </a>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="price-card price-active">
                <div class="price-head">
                  <i class="flaticon-car-wash"></i>
                  <h3>$23</h3>
                  <h4>Standard Plan</h4>
                </div>
                <ul class="price-list">
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>1 Recom Ad for 30 days</p>
                  </li>
                  <li>
                    <i class="fas fa-times"></i>
                    <p>No Featured Ad Available</p>
                  </li>
                  <li>
                    <i class="fas fa-times"></i>
                    <p>No Ad will be bumped up</p>
                  </li>
                  <li>
                    <i class="fas fa-times"></i>
                    <p>No Top Ad Available</p>
                  </li>
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>Basic Support</p>
                  </li>
                </ul>
                <div class="price-btn">
                  <a href="user-form.html" class="btn btn-inline">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Register Now</span>
                  </a>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="price-card">
                <div class="price-head">
                  <i class="flaticon-airplane"></i>
                  <h3>$49</h3>
                  <h4>Premium Plan</h4>
                </div>
                <ul class="price-list">
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>1 Featured Ad for 60 days</p>
                  </li>
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>Access to All features</p>
                  </li>
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>With Recommended</p>
                  </li>
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>Ad Top Category</p>
                  </li>
                  <li>
                    <i class="fas fa-plus"></i>
                    <p>Priority Support</p>
                  </li>
                </ul>
                <div class="price-btn">
                  <a href="user-form.html" class="btn btn-inline">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Register Now</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="blog-part">
        <div class="mx-5">
          <div class="row">
            <div class="col-lg-12">
              <div class="section-center-heading">
                <h2>
                  Read Our <span>Recent Articles</span>
                </h2>
                <p>
                  Dive into the Latest Gaming Buzz - Explore Our Recent Articles
                  Now!
                </p>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12">
              <div class="blog-slider slider-arrow">
                <div class="blog-card">
                  <div class="blog-img">
                    <img src="images/blog/01.jpg" alt="blog" />
                    <div class="blog-overlay">
                      <span class="marketing">Marketing</span>
                    </div>
                  </div>
                  <div class="blog-content">
                    <a href="#" class="blog-avatar">
                      <img src="images/avatar/01.jpg" alt="avatar" />
                    </a>
                    <ul class="blog-meta">
                      <li>
                        <i class="fas fa-user"></i>
                        <p>
                          <a href="#">MironMahmud</a>
                        </p>
                      </li>
                      <li>
                        <i class="fas fa-clock"></i>
                        <p>02 Feb 2021</p>
                      </li>
                    </ul>
                    <div class="blog-text">
                      <h4>
                        <a href="blog-details.html">
                          Lorem ipsum dolor sit amet eius minus elit cum quaerat
                          volupt.
                        </a>
                      </h4>
                      <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Temporibus veniam ad dolore labore laborum
                        perspiciatis...
                      </p>
                    </div>
                    <a href="blog-details.html" class="blog-read">
                      <span>read more</span>
                      <i class="fas fa-long-arrow-alt-right"></i>
                    </a>
                  </div>
                </div>
                <div class="blog-card">
                  <div class="blog-img">
                    <img src="images/blog/02.jpg" alt="blog" />
                    <div class="blog-overlay">
                      <span class="advertise">advertise</span>
                    </div>
                  </div>
                  <div class="blog-content">
                    <a href="#" class="blog-avatar">
                      <img src="images/avatar/02.jpg" alt="avatar" />
                    </a>
                    <ul class="blog-meta">
                      <li>
                        <i class="fas fa-user"></i>
                        <p>
                          <a href="#">LabonnoKhan</a>
                        </p>
                      </li>
                      <li>
                        <i class="fas fa-clock"></i>
                        <p>02 Feb 2021</p>
                      </li>
                    </ul>
                    <div class="blog-text">
                      <h4>
                        <a href="blog-details.html">
                          Lorem ipsum dolor sit amet eius minus elit cum quaerat
                          volupt.
                        </a>
                      </h4>
                      <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Temporibus veniam ad dolore labore laborum
                        perspiciatis...
                      </p>
                    </div>
                    <a href="blog-details.html" class="blog-read">
                      <span>read more</span>
                      <i class="fas fa-long-arrow-alt-right"></i>
                    </a>
                  </div>
                </div>
                <div class="blog-card">
                  <div class="blog-img">
                    <img src="images/blog/03.jpg" alt="blog" />
                    <div class="blog-overlay">
                      <span class="safety">safety</span>
                    </div>
                  </div>
                  <div class="blog-content">
                    <a href="#" class="blog-avatar">
                      <img src="images/avatar/03.jpg" alt="avatar" />
                    </a>
                    <ul class="blog-meta">
                      <li>
                        <i class="fas fa-user"></i>
                        <p>
                          <a href="#">MironMahmud</a>
                        </p>
                      </li>
                      <li>
                        <i class="fas fa-clock"></i>
                        <p>02 Feb 2021</p>
                      </li>
                    </ul>
                    <div class="blog-text">
                      <h4>
                        <a href="blog-details.html">
                          Lorem ipsum dolor sit amet eius minus elit cum quaerat
                          volupt.
                        </a>
                      </h4>
                      <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Temporibus veniam ad dolore labore laborum
                        perspiciatis...
                      </p>
                    </div>
                    <a href="blog-details.html" class="blog-read">
                      <span>read more</span>
                      <i class="fas fa-long-arrow-alt-right"></i>
                    </a>
                  </div>
                </div>
                <div class="blog-card">
                  <div class="blog-img">
                    <img src="images/blog/04.jpg" alt="blog" />
                    <div class="blog-overlay">
                      <span class="security">security</span>
                    </div>
                  </div>
                  <div class="blog-content">
                    <a href="#" class="blog-avatar">
                      <img src="images/avatar/04.jpg" alt="avatar" />
                    </a>
                    <ul class="blog-meta">
                      <li>
                        <i class="fas fa-user"></i>
                        <p>
                          <a href="#">TahminaBonny</a>
                        </p>
                      </li>
                      <li>
                        <i class="fas fa-clock"></i>
                        <p>02 Feb 2021</p>
                      </li>
                    </ul>
                    <div class="blog-text">
                      <h4>
                        <a href="blog-details.html">
                          Lorem ipsum dolor sit amet eius minus elit cum quaerat
                          volupt.
                        </a>
                      </h4>
                      <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Temporibus veniam ad dolore labore laborum
                        perspiciatis...
                      </p>
                    </div>
                    <a href="blog-details.html" class="blog-read">
                      <span>read more</span>
                      <i class="fas fa-long-arrow-alt-right"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12">
              <div class="blog-btn">
                <a href="blog-list.html" class="btn btn-inline">
                  <i class="fas fa-eye"></i>
                  <span>view all blogs</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div class="modal fade" id="currency">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h4>Choose a Currency</h4>
              <button class="fas fa-times" data-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <button class="modal-link active">
                United States Doller (USD) - $
              </button>
              <button class="modal-link">Euro (EUR) - €</button>
              <button class="modal-link">British Pound (GBP) - £</button>
              <button class="modal-link">Australian Dollar (AUD) - A$</button>
              <button class="modal-link">Canadian Dollar (CAD) - C$</button>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="language">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h4>Choose a Language</h4>
              <button class="fas fa-times" data-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <button class="modal-link active">English</button>
              <button class="modal-link">bangali</button>
              <button class="modal-link">arabic</button>
              <button class="modal-link">germany</button>
              <button class="modal-link">spanish</button>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default Section;
